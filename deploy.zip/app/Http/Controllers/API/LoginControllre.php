<?php

namespace App\Http\Controllers\API;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\jabatan;
use App\pegawai;
use App\client;
use DB;
use App\JadwalShift;
use Illuminate\Support\Facades\Auth;
use Validator;

class LoginControllre extends Controller
{
    public $successStatus = 200;

    public function login(){
        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){
            $user = Auth::user();
            $success['token'] =  $user->createToken('nApp')->accessToken;
            $id = $user->id_pegawai;
            // lat long
            $lokasi= [];
            $id_kantor = client::select('id')->get();
            foreach($id_kantor as $kantor){
            $id_kantor = $kantor->id;
            $lat = client::where('id',$id_kantor)->value('lat');
            $long = client::where('id',$id_kantor)->value('long');
            $lokasi[] = ['id_kantor'=>$kantor->id,'lat'=>$lat,'long'=>$long];
            }
            $lat = client::select('lat','id')->get();
            $long = client::select('long','id')->get();
            $jabatan_id = pegawai::where('id',$id)->value('id_jabatan');
            $jabatan_id = pegawai::where('id',$id)->value('id_jabatan');
            $date = date('Y-m-d');
            // check shift pegawai
            $check_shift = JadwalShift::where('date',$date)->where('Ids',$id)->value('shift');
            $masuk = DB::table('shift')->where('id',$check_shift)->value('jam_masuk');
            $pulang = DB::table('shift')->where('id',$check_shift)->value('jam_pulang');
            
            return response()->json([
            'message'=>"Berhasil Login",
            'data' =>([
                'user_id'=> $id,
                'user_nama'=>$user->name,
                'user_jabatan_id'=>$jabatan_id,
                'user_email'=>$user->email,
                'user_no_hp'=>$user->telp,
                "user_mulai_shift" => $masuk,
                "user_sampai_shift" => $pulang,
                "user_kantor"=>$lokasi,
                "user_url_photo"=>$user->gambar,
 
            ]),
            'auth'=>$success,
        
        ], $this->successStatus);
        }
        else{
            return response()->json(['error'=>'Password atau email anda salah'], 401);
        }
    }

}
