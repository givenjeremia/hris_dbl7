<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class slugJadwal extends Model
{
    protected $table = 'slug_jadwal_shifts';
}
