$(function () {
  let list =[
    {
                  data: 'id', render: function (data, type, row, meta) {
                      return meta.row + meta.settings._iDisplayStart + 1;
                  }
              },
              { data: 'id_pegawai', name: 'id_pegawai' },
              { data: 'masuk', name: 'masuk' },
              { data: 'pulang', name: 'pulang' },
              { data: 'pulang', name: 'pulang' },
              {
                            render: function (data, type, row) {
                                return '<a href="/backend/' + row['id'] + '/edit/'+ data +'" class="btn btn-success"><i class="fa fa-wrench"></i></a> <button class="btn btn-danger" onclick="hapusdata(' + row['id'] + ')"><i class="fa fa-trash"></i></button>'
                            },
                            "className": 'text-center',
                            "orderable": false,
                            "data": null,
                        },
  ]
  
  for (let i = 1; i < 31; i++){
    list.push({ data: 'id_pegawai '+ i +'', name: 'id_pegawai' },);
   
  }
  console.log(list);
  $('#list-data').DataTable({
      processing: true,
      serverSide: true,
      order: [[0, "desc"]],
      ajax: '/backend/data-absen',
      columns: list,
      // [
        
  //         {
  //             data: 'id', render: function (data, type, row, meta) {
  //                 return meta.row + meta.settings._iDisplayStart + 1;
  //             }
  //         },
  //         { data: 'id_pegawai', name: 'id_pegawai' },
  //         { data: 'masuk', name: 'masuk' },
  //         { data: 'pulang', name: 'pulang' },
  //         { data: 'status', name: 'status' },
  //         { data: 'long', name: 'long' },
  //         {
  //             render: function (data, type, row) {
  //                 return '<a href="/backend/' + row['id'] + '/edit/'+ data +'" class="btn btn-success"><i class="fa fa-wrench"></i></a> <button class="btn btn-danger" onclick="hapusdata(' + row['id'] + ')"><i class="fa fa-trash"></i></button>'
  //             },
  //             "className": 'text-center',
  //             "orderable": false,
  //             "data": null,
  //         },
  //     ],
      pageLength: 10,
      lengthMenu: [[5, 10, 20], [5, 10, 20]]
  });

});
function inputjadwal(){
//  get data
  let url ='http://127.0.0.1:8000'
  let data = $.getJSON(''+ url+'/backend/list-add-jadwal',
    function(resource){
      // data date
      const month = [
      { 'bulan':"January",'id':String(1).padStart(2, '0')},
      { 'bulan':"February",'id':String(2).padStart(2, '0')},
      { 'bulan':"March",'id':String(3).padStart(2, '0')},
      { 'bulan':"April",'id':String(4).padStart(2, '0')},
      { 'bulan':"May",'id':String(5).padStart(2, '0')},
      { 'bulan':"June",'id':String(6).padStart(2, '0')},
      { 'bulan':"July",'id':String(7).padStart(2, '0')},
      { 'bulan':"August",'id':String(8).padStart(2, '0')},
      { 'bulan':"September",'id':String(9).padStart(2, '0')},
      { 'bulan':"October",'id':10},
      { 'bulan':"November",'id':11},
      { 'bulan':"December",'id':12},
    ];
// looping data
      let category = ['Devisi','Jabatan','Pegawai'];
      const jabatans = resource.data.jabatan;
      const pegawai = resource.data.pegawai;
      const devisi = resource.data.devisi;
      var options_jabatan = {};
      var options_devisi = {};
      var options_pegawai = {};
      var options_category = {};
      var options_mount = {};

    $.map(jabatans,
        function(o) {
            options_jabatan[o.id] = [o.nama];
        });
    $.map(category,
          function(o){
            options_category[o]=[o];
          }
      );
      $.map(pegawai,
        function(o){
          options_pegawai[o.id]=[o.nama];
        }
    );
    $.map(devisi,
      function(o){
        options_devisi[o.id]=[o.nama];
      }
  );
  $.map(month,
    function(o){
      options_mount[o.id]=[o.bulan];
    }
);
      (async () => {
        const steps = ['1', '2', '3']
        const Queue = Swal.mixin({
      progressSteps: steps,
      confirmButtonText: 'Next',
    })
    // Sweet alert category
    
    const { value: categorys } =  await Queue.fire({
      title: 'Pilih Kategori ',
      input: 'select',
      inputOptions:options_category,
      inputValue: '1',
      confirmButtonText: 'Next',
      showCancelButton: true,
      currentProgressStep: 0,
      showClass: { backdrop: 'swal2-noanimation' },
    })
    // category devisi
    if (categorys == category[0]){
      const { value: id } = await Queue.fire({
      title: 'Select Devisi',
      input: 'select',
      inputOptions:options_devisi,
      inputValue: '1',
      confirmButtonText: 'Next',
      showCancelButton: true,
      currentProgressStep: 1,
      showClass: { backdrop: 'swal2-noanimation' }
      
    })
    function getId(){
      return id;
  }
}
////////////////////////////////////////////        
/////////// category jabatan////////////////
      else if (categorys == category[1]){
        const { value: id } = await Queue.fire({
        title: 'Select Jabatan',
        input: 'select',
        inputOptions:options_jabatan,
        inputValue: '1',
        confirmButtonText: 'Next',
        showCancelButton: true,
        currentProgressStep: 1,
        showClass: { backdrop: 'swal2-noanimation' },
      
      })
      function getId(){
          return id;
      }
      }
        
        
      //////////////////////////////////////
    // category pegawai/////////////////
    else if (categorys == category[2]){
      const { value: id } = await Queue.fire({
      title: 'Select Pegawai',
      input: 'select',
      inputOptions:options_pegawai,
      inputValue: '1',
      confirmButtonText: 'Next',
      showCancelButton: true,
      currentProgressStep: 1,
   
   })
   function getId(){
    return id;
}
   }
   ///////////////////////////////////
    const getid = getId();
    if(getid != null ){
    const { value: dates } = await Queue.fire({
    title: 'Select Mounts',
    input: 'select',
    inputOptions:options_mount,
    inputValue: '1',
    confirmButtonText: 'next',
    showCancelButton: true,
    currentProgressStep: 2,
  
  }
  )
  function getdates(){
    return dates
  }
   }
  
   await Queue.fire({
    title: 'Can You Send?',
    confirmButtonText: 'Send',
    currentProgressStep: 3,
  
  }
  ).then(function(){
    window.location.assign(''+ url+'/backend/add-jadwal/'+ getId() +'/'+ getdates()+'/'+ categorys +'')
  });
      })()
    }
  );

 
}
///////////// table Jadwal Shift/////////
